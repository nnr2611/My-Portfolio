import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"

export function About() {
  return (
    <section id="about" className="py-16 md:py-24 bg-muted/30">
      <div className="container">
        <h2 className="text-3xl font-bold text-center mb-12">About Me</h2>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="flex justify-center">
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-primary/20">
              <Image src="/placeholder.svg?height=320&width=320" alt="Profile" fill className="object-cover" />
            </div>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-4">Who Am I</h3>
            <p className="text-muted-foreground mb-6">
             I am a passionate Software developer, with a dabble of interest in building electronic sub systems. 
             </p>
             <p className="text-muted-foreground mb-6">
             I am someone who is focused on continuous improvement and always looking for opportunies to learn something new, and interesting projects to develop.
             </p>
            <p className="text-muted-foreground mb-6">
              I try to take a creative approach to solve the problems that I face and deliver functional and intuitive solutions. 
              Constant learning and exploring new technologies is my Jam.
            </p>
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Download Resume
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

